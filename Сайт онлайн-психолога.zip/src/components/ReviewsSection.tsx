import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from './ui/carousel';
import { Star, Quote } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function ReviewsSection() {
  const reviews = [
    {
      name: "Елена Козлова",
      role: "Менеджер проектов",
      image: "https://images.unsplash.com/photo-1669689290695-7f0efe5d4c8e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMHdvbWFuJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzU3Njg1Njg0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 5,
      text: "Пётр помог мне справиться с тревожностью и неуверенностью в себе. После работы с ним я стала более спокойной и научилась лучше управлять своими эмоциями.",
      category: "Личная психология"
    },
    {
      name: "Михаил Петров",
      role: "Предприниматель", 
      image: "https://images.unsplash.com/photo-1672685667592-0392f458f46f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBtYW4lMjBwb3J0cmFpdHxlbnwxfHx8fDE3NTc3MzgzNzV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 5,
      text: "Отличный специалист! Помог разобраться с проблемами в бизнесе и личной жизни. Очень профессиональный подход и реальные результаты.",
      category: "Бизнес-психология"
    },
    {
      name: "Анастасия Волкова",
      role: "Маркетолог",
      image: "https://images.unsplash.com/photo-1592246031317-eb6c0931b7e7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWlsaW5nJTIwd29tYW4lMjBidXNpbmVzc3dvbWFufGVufDF8fHx8MTc1Nzc1Nzc5MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 5,
      text: "Благодаря работе с Петром мой брак удалось сохранить. Он научил нас правильно общаться и понимать друг друга. Очень благодарна!",
      category: "Семейная психология"
    },
    {
      name: "Дмитрий Соколов",
      role: "IT-директор",
      image: "https://images.unsplash.com/photo-1584940121258-c2553b66a739?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25maWRlbnQlMjBtYW4lMjBleGVjdXRpdmV8ZW58MXx8fHwxNzU3NzU3NzkyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 5,
      text: "Профессиональный выгорание было серьезной проблемой. Пётр помог найти баланс между работой и личной жизнью. Рекомендую всем!",
      category: "Бизнес-психология"
    },
    {
      name: "Ольга Романова",
      role: "Дизайнер",
      image: "https://images.unsplash.com/photo-1701760172439-3f3f40bdfaa7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMHdvbWFuJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc1Nzc1Nzc5Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 5,
      text: "Замечательный психолог! Очень деликатно и профессионально помог справиться с депрессией. Теперь я снова радуюсь жизни.",
      category: "Личная психология"
    },
    {
      name: "Владимир Федоров",
      role: "Руководитель отдела",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400",
      rating: 5,
      text: "Работа с командой стала намного эффективнее после консультаций с Петром. Он научил меня быть лучшим лидером.",
      category: "Бизнес-психология"
    },
    {
      name: "Светлана Морозова",
      role: "Учитель",
      image: "https://images.unsplash.com/photo-1580894732444-8ecded7900cd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400",
      rating: 5,
      text: "Семейная терапия с Петром помогла наладить отношения с подростком-сыном. Очень благодарна за терпение и профессионализм.",
      category: "Семейная психология"
    },
    {
      name: "Игорь Кузнецов",
      role: "Программист",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400",
      rating: 5,
      text: "Социальная тревожность мешала карьере. Пётр помог стать более уверенным в общении с коллегами и клиентами.",
      category: "Личная психология"
    },
    {
      name: "Екатерина Смирнова",
      role: "Врач",
      image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400",
      rating: 5,
      text: "Прекрасный специалист! Помог разобраться с внутренними конфликтами и найти свой путь. Очень рекомендую.",
      category: "Личная психология"
    },
    {
      name: "Алексей Васильев",
      role: "Менеджер по продажам",
      image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400",
      rating: 5,
      text: "Развитие лидерских качеств и уверенности в себе — именно то, что я получил от работы с Петром. Очень доволен результатом.",
      category: "Бизнес-психология"
    },
    {
      name: "Марина Козлова",
      role: "Психолог",
      image: "https://images.unsplash.com/photo-1581065178026-390bc4e78dad?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB3b21hbiUyMHBvcnRyYWl0fGVufDF8fHx8MTc1OTAyMTM3MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 5,
      text: "Как коллега могу сказать — Пётр настоящий профессионал. Работала с ним в сложном случае семейной терапии. Отличные результаты!",
      category: "Семейная психология"
    },
    {
      name: "Роман Орлов",
      role: "Финансовый аналитик", 
      image: "https://images.unsplash.com/photo-1629507208649-70919ca33793?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzc21hbiUyMHByb2Zlc3Npb25hbCUyMHBvcnRyYWl0fGVufDF8fHx8MTc1OTA2OTc3MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 5,
      text: "Стресс на работе и проблемы в семье казались неразрешимыми. Пётр помог найти баланс и восстановить гармонию.",
      category: "Личная психология"
    },
    {
      name: "Татьяна Лебедева",
      role: "HR-директор",
      image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400",
      rating: 5,
      text: "Профессиональная работа с командой топ-менеджеров. Пётр помог улучшить коммуникацию и повысить эффективность.",
      category: "Бизнес-психология"
    },
    {
      name: "Андрей Новиков",
      role: "Предприниматель",
      image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400",
      rating: 5,
      text: "Кризис среднего возраста и неопределенность в карьере — с этим помог справиться Пётр. Теперь четко вижу свои цели.",
      category: "Личная психология"
    },
    {
      name: "Юлия Семенова",
      role: "Журналист",
      image: "https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400",
      rating: 5,
      text: "Работа с детскими травмами требует особого мастерства. Пётр провел меня через этот процесс очень бережно и профессионально.",
      category: "Личная психология"
    },
    {
      name: "Павел Медведев",
      role: "Архитектор",
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400",
      rating: 5,
      text: "Семейные проблемы и развод казались неизбежными. Благодаря Петру мы смогли сохранить семью и стать еще ближе.",
      category: "Семейная психология"
    },
    {
      name: "Наталья Иванова",
      role: "Бухгалтер",
      image: "https://images.unsplash.com/photo-1607746882042-944635dfe10e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400",
      rating: 5,
      text: "Панические атаки мешали нормально жить и работать. Пётр помог справиться с ними и вернуть уверенность в себе.",
      category: "Личная психология"
    },
    {
      name: "Сергей Попов",
      role: "Инженер",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400",
      rating: 5,
      text: "Отличный специалист! Помог разобраться с проблемами самооценки и найти мотивацию для достижения целей.",
      category: "Личная психология"
    },
    {
      name: "Виктория Белова",
      role: "Маркетолог",
      image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400",
      rating: 5,
      text: "Работа с Петром помогла мне найти баланс между материнством и карьерой. Очень ��лагодарна за поддержку и понимание.",
      category: "Личная психология"
    },
    {
      name: "Максим Григорьев",
      role: "Стартапер",
      image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400",
      rating: 5,
      text: "Стресс от запуска стартапа и управления командой был огромным. Пётр научил меня справляться с давлением и принимать решения.",
      category: "Бизнес-психология"
    }
  ];

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Личная психология":
        return "bg-blue-100 text-blue-700 border-blue-200";
      case "Семейная психология":
        return "bg-green-100 text-green-700 border-green-200";
      case "Бизнес-психология":
        return "bg-purple-100 text-purple-700 border-purple-200";
      default:
        return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  return (
    <section id="reviews" className="py-16 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="bg-yellow-100 text-yellow-700 border-yellow-200 mb-4">
            <Star className="w-4 h-4 mr-1" />
            Отзывы клиентов
          </Badge>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl mb-4 text-gray-900 px-4 sm:px-0 break-words">
            Что говорят мои клиенты
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto px-4 sm:px-0 break-words">
            Честные отзывы людей, которые изменили свою жизнь к лучшему. 
            Каждая история уникальна, но объединяет их одно — желание стать счастливее.
          </p>
        </div>

        {/* Карусель отзывов */}
        <Carousel className="w-full mb-12">
          <CarouselContent className="-ml-4">
            {reviews.map((review, index) => (
              <CarouselItem key={index} className="pl-4 basis-full md:basis-1/2 lg:basis-1/3">
                <Card className="h-full p-4 sm:p-6 hover:shadow-lg transition-shadow duration-300">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 rounded-full overflow-hidden mr-4 bg-gray-100">
                      <ImageWithFallback
                        src={review.image}
                        alt={review.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-gray-900 mb-1">{review.name}</h4>
                      <p className="text-sm text-gray-600">{review.role}</p>
                    </div>
                  </div>

                  <Badge 
                    variant="secondary" 
                    className={`mb-4 ${getCategoryColor(review.category)}`}
                  >
                    {review.category}
                  </Badge>

                  <div className="flex items-center mb-4">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-500 fill-current" />
                    ))}
                  </div>

                  <div className="relative">
                    <Quote className="w-6 h-6 text-gray-300 absolute -top-2 -left-1" />
                    <p className="text-gray-700 italic pl-4 break-words">{review.text}</p>
                  </div>
                </Card>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="hidden md:flex" />
          <CarouselNext className="hidden md:flex" />
        </Carousel>

        {/* Статист��ка */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-6 sm:p-8 text-white text-center">
          <h3 className="text-xl sm:text-2xl mb-6 sm:mb-8 px-2">Результаты говорят сами за себя</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-8">
            <div>
              <div className="text-2xl sm:text-3xl mb-1 sm:mb-2">500+</div>
              <div className="text-blue-100 text-sm sm:text-base">Довольных клиентов</div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl mb-1 sm:mb-2">95%</div>
              <div className="text-blue-100 text-sm sm:text-base">Положительных отзывов</div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl mb-1 sm:mb-2">4.9</div>
              <div className="text-blue-100 text-sm sm:text-base">Средний рейтинг</div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl mb-1 sm:mb-2">10+</div>
              <div className="text-blue-100 text-sm sm:text-base">Лет опыта</div>
            </div>
          </div>
        </div>

        {/* Призыв к действию */}
        <div className="mt-12 text-center">
          <h3 className="text-2xl text-gray-900 mb-4">Готовы изменить свою жизнь?</h3>
          <p className="text-gray-600 mb-6 max-w-2xl mx-auto break-words px-4">
            Присоединитесь к сотням людей, которые уже нашли свой путь к счастью и гармонии. 
            Начните свое путешествие к лучшей версии себя уже сегодня.
          </p>
        </div>
      </div>
    </section>
  );
}
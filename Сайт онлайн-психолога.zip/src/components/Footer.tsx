import React from 'react';
import { Heart, Shield, Award, MessageCircle, Phone } from 'lucide-react';
import { Badge } from './ui/badge';

export function Footer() {
  const handleWhatsAppClick = () => {
    const message = encodeURIComponent('Здравствуйте, пишу по консультации психолога');
    window.open(`https://wa.me/79232205524?text=${message}`, '_blank');
  };

  const handleTelegramClick = () => {
    window.open('https://t.me/+79232205524', '_blank');
  };

  const handlePhoneClick = () => {
    window.open('tel:+79232205524', '_blank');
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* О психологе */}
          <div className="md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg flex items-center justify-center">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl">Психолог Пётр</span>
            </div>
            <p className="text-gray-300 mb-4 max-w-lg break-words">
              Профессиональный психолог с более чем 10-летним опытом работы. 
              Помогаю людям найти внутреннюю гармонию, наладить отношения и достичь личных целей.
            </p>
            <div className="flex flex-wrap gap-2">
              <Badge variant="secondary" className="bg-blue-900 text-blue-200 border-blue-800">
                <Award className="w-3 h-3 mr-1" />
                Лицензированный специалист
              </Badge>
              <Badge variant="secondary" className="bg-green-900 text-green-200 border-green-800">
                <Shield className="w-3 h-3 mr-1" />
                10+ лет опыта
              </Badge>
            </div>
          </div>

          {/* Быстрые ссылки */}
          <div>
            <h3 className="text-lg mb-4">Быстрые ссылки</h3>
            <div className="space-y-2">
              <button 
                onClick={() => scrollToSection('hero')}
                className="block text-gray-300 hover:text-white transition-colors"
              >
                Главная
              </button>
              <button 
                onClick={() => scrollToSection('about')}
                className="block text-gray-300 hover:text-white transition-colors"
              >
                О психологе
              </button>
              <button 
                onClick={() => scrollToSection('services')}
                className="block text-gray-300 hover:text-white transition-colors"
              >
                Услуги
              </button>
              <button 
                onClick={() => scrollToSection('reviews')}
                className="block text-gray-300 hover:text-white transition-colors"
              >
                Отзывы
              </button>
              <button 
                onClick={() => scrollToSection('contact')}
                className="block text-gray-300 hover:text-white transition-colors"
              >
                Контакты
              </button>
            </div>
          </div>

          {/* Контакты */}
          <div>
            <h3 className="text-lg mb-4">Связаться со мной</h3>
            <div className="space-y-3">
              <button 
                onClick={handleWhatsAppClick}
                className="flex items-center text-gray-300 hover:text-green-400 transition-colors w-full text-left"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                WhatsApp
              </button>
              <button 
                onClick={handleTelegramClick}
                className="flex items-center text-gray-300 hover:text-blue-400 transition-colors w-full text-left"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Telegram
              </button>
              <button 
                onClick={handlePhoneClick}
                className="flex items-center text-gray-300 hover:text-white transition-colors w-full text-left"
              >
                <Phone className="w-4 h-4 mr-2" />
                8 (923) 220-55-24
              </button>

            </div>
          </div>
        </div>

        {/* Специализации */}
        <div className="border-t border-gray-800 pt-8 mb-8">
          <h3 className="text-lg mb-4">Специализации</h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <h4 className="text-white mb-2">Личная психология</h4>
              <p className="text-gray-400 text-sm break-words">
                Работа с тревогой, депрессией, самооценкой, личностным ростом и поиском смысла жизни.
              </p>
            </div>
            <div>
              <h4 className="text-white mb-2">Семейная психология</h4>
              <p className="text-gray-400 text-sm break-words">
                Решение семейных конфликтов, улучшение отношений в паре, работа с детско-родительскими отношениями.
              </p>
            </div>
            <div>
              <h4 className="text-white mb-2">Бизнес-психология</h4>
              <p className="text-gray-400 text-sm break-words">
                Развитие лидерских качеств, управление стрессом, командная работа, профессиональное выгорание.
              </p>
            </div>
          </div>
        </div>

        {/* Нижняя часть */}
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-gray-400 text-sm mb-4 md:mb-0">
              © 2024 Психолог Пётр Петров. Все права защищены.
            </div>
            <div className="flex flex-col sm:flex-row items-center justify-center sm:space-x-3 md:space-x-4 lg:space-x-6 space-y-2 sm:space-y-0 text-xs sm:text-sm text-gray-400 text-center max-w-4xl mx-auto">
              <span className="px-2">Лицензия № ПС-2024-001</span>
              <span className="hidden sm:inline">•</span>
              <span className="px-2">Конфиденциальность гарантирована</span>
              <span className="hidden sm:inline">•</span>
              <span className="px-2">Работаю по этическим стандартам</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
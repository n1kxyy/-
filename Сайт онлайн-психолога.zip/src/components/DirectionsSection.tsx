import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { 
  Heart, 
  Users, 
  Briefcase, 
  Target, 
  Brain, 
  Shield, 
  Compass, 
  ArrowRight,
  CheckCircle
} from 'lucide-react';

export function DirectionsSection() {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const directions = [
    {
      category: "Работа с собой",
      icon: Heart,
      color: "rose",
      description: "Познание себя, личностный рост и эмоциональное благополучие",
      issues: [
        "Низкая самооценка и неуверенность в себе",
        "Тревога, страхи и панические атаки", 
        "Депрессивные состояния и апатия",
        "Стресс и эмоциональное выгорание",
        "Поиск смысла жизни и предназначения",
        "Проработка детских травм",
        "Развитие эмоционального интеллекта"
      ]
    },
    {
      category: "Семейные отношения",
      icon: Users,
      color: "green", 
      description: "Гармонизация отношений в семье и создание крепких связей",
      issues: [
        "Конфликты и непонимание в паре",
        "Проблемы в общении с детьми",
        "Кризис в браке и угроза развода",
        "Ревность и недоверие в отношениях",
        "Проблемы с интимностью",
        "Адаптация к новым ролям (родительство)",
        "Работа с созависимостью"
      ]
    },
    {
      category: "Бизнес и карьера",
      icon: Briefcase,
      color: "blue",
      description: "Профессиональное развитие и достижение карьерных целей",
      issues: [
        "Выбор профессии и смена деятельности",
        "Развитие лидерских качеств",
        "Управление командой и мотивация",
        "Преодоление профессионального выгорания",
        "Работа с импостер-синдромом",
        "Баланс работы и личной жизни",
        "Принятие сложных решений"
      ]
    },
    {
      category: "Личностное развитие",
      icon: Target,
      color: "purple",
      description: "Раскрытие потенциала и достижение жизненных целей",
      issues: [
        "Постановка и достижение целей",
        "Развитие навыков коммуникации",
        "Преодоление прокрастинации",
        "Формирование полезных привычек",
        "Работа с перфекционизмом",
        "Развитие креативности",
        "Повышение мотивации и энергии"
      ]
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      rose: {
        bg: "bg-rose-50",
        border: "border-rose-200", 
        icon: "bg-rose-100 text-rose-600",
        badge: "bg-rose-100 text-rose-700 border-rose-200"
      },
      green: {
        bg: "bg-green-50",
        border: "border-green-200",
        icon: "bg-green-100 text-green-600", 
        badge: "bg-green-100 text-green-700 border-green-200"
      },
      blue: {
        bg: "bg-blue-50",
        border: "border-blue-200",
        icon: "bg-blue-100 text-blue-600",
        badge: "bg-blue-100 text-blue-700 border-blue-200"
      },
      purple: {
        bg: "bg-purple-50", 
        border: "border-purple-200",
        icon: "bg-purple-100 text-purple-600",
        badge: "bg-purple-100 text-purple-700 border-purple-200"
      }
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <section className="py-16 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="bg-indigo-100 text-indigo-700 border-indigo-200 mb-4">
            <Compass className="w-4 h-4 mr-1" />
            Направления помощи
          </Badge>
          <h2 className="text-3xl lg:text-4xl mb-4 text-gray-900 break-words">
            В чем я могу помочь
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto break-words px-4">
            Подробный обзор проблем и задач, с которыми я работаю. Найдите свое направление 
            или получите консультацию для определения подходящего метода работы.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {directions.map((direction, index) => {
            const IconComponent = direction.icon;
            const colorClasses = getColorClasses(direction.color);

            return (
              <Card key={index} className={`p-6 ${colorClasses.bg} ${colorClasses.border} hover:shadow-lg transition-shadow duration-300`}>
                <div className="flex items-center mb-4">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center mr-4 ${colorClasses.icon}`}>
                    <IconComponent className="w-6 h-6" />
                  </div>
                  <div>
                    <Badge className={colorClasses.badge}>
                      {direction.category}
                    </Badge>
                    <p className="text-gray-600 text-sm mt-1">{direction.description}</p>
                  </div>
                </div>

                <div className="space-y-3">
                  {direction.issues.map((issue, issueIndex) => (
                    <div key={issueIndex} className="flex items-start">
                      <CheckCircle className="w-4 h-4 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700 text-sm">{issue}</span>
                    </div>
                  ))}
                </div>
              </Card>
            );
          })}
        </div>

        {/* Блок помощи в выборе направления */}
        <Card className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white p-4 sm:p-6 lg:p-8 text-center">
          <div className="max-w-xs sm:max-w-lg md:max-w-2xl lg:max-w-3xl xl:max-w-4xl mx-auto w-full px-4 sm:px-6 lg:px-8">
            <div className="w-10 h-10 xs:w-12 xs:h-12 sm:w-14 sm:h-14 md:w-16 md:h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3 xs:mb-4 sm:mb-5 md:mb-6">
              <Compass className="w-5 h-5 xs:w-6 xs:h-6 sm:w-7 sm:h-7 md:w-8 md:h-8" />
            </div>
            
            <h3 className="text-lg xs:text-xl sm:text-xl md:text-2xl lg:text-3xl mb-2 xs:mb-3 sm:mb-3 md:mb-4 text-center leading-tight">
              Не знаете, какое направление выбрать?
            </h3>
            <p className="text-indigo-100 mb-4 xs:mb-5 sm:mb-6 md:mb-7 lg:mb-8 text-sm xs:text-base sm:text-base md:text-lg lg:text-xl text-center leading-relaxed max-w-2xl mx-auto">
              Запишитесь на бесплатную 30-минутную консультацию. Вместе мы определим, 
              какой подход будет наиболее эффективным именно для вас.
            </p>

            <div className="grid grid-cols-1 xs:grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 xs:gap-4 sm:gap-5 md:gap-6 mb-4 xs:mb-5 sm:mb-6 md:mb-7 lg:mb-8 max-w-2xl lg:max-w-none mx-auto">
              <div className="flex items-center justify-center space-x-2 xs:space-x-2 sm:space-x-3 py-2 xs:py-3 sm:py-4 bg-white/10 rounded-lg sm:bg-transparent sm:py-2">
                <Brain className="w-4 h-4 xs:w-5 xs:h-5 sm:w-5 sm:h-5 md:w-6 md:h-6 text-indigo-200 flex-shrink-0" />
                <span className="text-indigo-100 text-xs xs:text-sm sm:text-sm md:text-base font-medium text-center">Диагностика проблемы</span>
              </div>
              <div className="flex items-center justify-center space-x-2 xs:space-x-2 sm:space-x-3 py-2 xs:py-3 sm:py-4 bg-white/10 rounded-lg sm:bg-transparent sm:py-2">
                <Target className="w-4 h-4 xs:w-5 xs:h-5 sm:w-5 sm:h-5 md:w-6 md:h-6 text-indigo-200 flex-shrink-0" />
                <span className="text-indigo-100 text-xs xs:text-sm sm:text-sm md:text-base font-medium text-center">Постановка целей</span>
              </div>
              <div className="flex items-center justify-center space-x-2 xs:space-x-2 sm:space-x-3 py-2 xs:py-3 sm:py-4 bg-white/10 rounded-lg sm:bg-transparent sm:py-2 sm:col-span-2 lg:col-span-1">
                <Shield className="w-4 h-4 xs:w-5 xs:h-5 sm:w-5 sm:h-5 md:w-6 md:h-6 text-indigo-200 flex-shrink-0" />
                <span className="text-indigo-100 text-xs xs:text-sm sm:text-sm md:text-base font-medium text-center">План работы</span>
              </div>
            </div>

            <div className="flex justify-center w-full">
              <Button 
                onClick={scrollToContact}
                className="bg-white text-indigo-600 hover:bg-gray-100 focus:ring-2 focus:ring-white/50 px-3 xs:px-4 sm:px-5 md:px-6 lg:px-8 py-2 xs:py-2 sm:py-2.5 md:py-3 rounded-lg text-xs xs:text-sm sm:text-sm md:text-base lg:text-lg w-full xs:w-full sm:w-auto max-w-sm sm:max-w-none transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                <span className="block xs:block sm:inline">Получить бесплатную</span>
                <span className="block xs:block sm:inline sm:ml-1">консультацию</span>
                <ArrowRight className="w-3 h-3 xs:w-4 xs:h-4 sm:w-4 sm:h-4 md:w-5 md:h-5 ml-1 xs:ml-2 inline-block flex-shrink-0" />
              </Button>
            </div>
          </div>
        </Card>

        {/* Дополнительная информация */}
        <div className="mt-12 grid md:grid-cols-2 gap-8">
          <Card className="p-6 bg-white">
            <h3 className="text-xl text-gray-900 mb-4">Как проходит работа</h3>
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3 mt-1 flex-shrink-0">
                  <span className="text-blue-600 text-sm">1</span>
                </div>
                <div>
                  <h4 className="text-gray-900 mb-1">Первичная консультация</h4>
                  <p className="text-gray-600 text-sm">Знакомство, анализ ситуации и постановка целей</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-3 mt-1 flex-shrink-0">
                  <span className="text-green-600 text-sm">2</span>
                </div>
                <div>
                  <h4 className="text-gray-900 mb-1">Разработка плана</h4>
                  <p className="text-gray-600 text-sm">Создание индивидуальной программы работы</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center mr-3 mt-1 flex-shrink-0">
                  <span className="text-purple-600 text-sm">3</span>
                </div>
                <div>
                  <h4 className="text-gray-900 mb-1">Работа с проблемой</h4>
                  <p className="text-gray-600 text-sm">Регулярные сессии и домашние задания</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center mr-3 mt-1 flex-shrink-0">
                  <span className="text-orange-600 text-sm">4</span>
                </div>
                <div>
                  <h4 className="text-gray-900 mb-1">Закрепление результата</h4>
                  <p className="text-gray-600 text-sm">Поддержка и профилактические встречи</p>
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-white">
            <h3 className="text-xl text-gray-900 mb-4">Гарантии результата</h3>
            <div className="space-y-4">
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                <span className="text-gray-700">Индивидуальный подход к каждому клиенту</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                <span className="text-gray-700">Конкретные техники и домашние задания</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                <span className="text-gray-700">Поддержка между сессиями</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                <span className="text-gray-700">Возможность корректировки плана работы</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                <span className="text-gray-700">Полная конфиденциальность</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                <span className="text-gray-700">Гибкое расписание и формат работы</span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
}
import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Heart, Users, Lightbulb, Star, Clock, Trophy } from 'lucide-react';

export function AboutSection() {
  return (
    <section id="about" className="py-16 bg-gradient-to-br from-purple-50 via-white to-blue-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="bg-purple-100 text-purple-700 border-purple-200 mb-4">
            <Heart className="w-4 h-4 mr-1" />
            О психологе
          </Badge>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl mb-4 text-gray-900 px-4 sm:px-0 break-words">
            Пётр Петров
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto px-4 sm:px-0 break-words">
            Профессиональный психолог с более чем 10-летним опытом работы. 
            Специализируюсь на личной и семейной психологии, помогая людям найти 
            внутреннюю гармонию и наладить отношения.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Личные качества */}
          <div>
            <h3 className="text-2xl text-gray-900 mb-6">Мой подход к работе</h3>
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                  <Heart className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h4 className="text-lg text-gray-900 mb-2">Доброта и эмпатия</h4>
                  <p className="text-gray-600 break-words">
                    Создаю атмосферу доверия и понимания, где каждый человек чувствует себя принятым и услышанным.
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                  <Star className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h4 className="text-lg text-gray-900 mb-2">Профессионализм</h4>
                  <p className="text-gray-600 break-words">
                    Использую научно-обоснованные методы и постоянно повышаю квалификацию для достижения лучших результатов.
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                  <Lightbulb className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <h4 className="text-lg text-gray-900 mb-2">Внимательность</h4>
                  <p className="text-gray-600 break-words">
                    Тщательно анализирую каждую ситуацию и нахожу индивидуальные решения для каждого клиента.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Достижения и опыт */}
          <div>
            <h3 className="text-xl sm:text-2xl text-gray-900 mb-6">Опыт и достижения</h3>
            <div className="grid grid-cols-2 gap-3 sm:gap-4 mb-6">
              <Card className="p-3 sm:p-4 text-center bg-white border-blue-200">
                <Clock className="w-6 h-6 sm:w-8 sm:h-8 text-blue-600 mx-auto mb-2" />
                <div className="text-lg sm:text-2xl text-gray-900">10+</div>
                <div className="text-xs sm:text-sm text-gray-600">лет опыта</div>
              </Card>
              <Card className="p-3 sm:p-4 text-center bg-white border-green-200">
                <Users className="w-6 h-6 sm:w-8 sm:h-8 text-green-600 mx-auto mb-2" />
                <div className="text-lg sm:text-2xl text-gray-900">500+</div>
                <div className="text-xs sm:text-sm text-gray-600">помог клиентам</div>
              </Card>
              <Card className="p-3 sm:p-4 text-center bg-white border-purple-200">
                <Star className="w-6 h-6 sm:w-8 sm:h-8 text-purple-600 mx-auto mb-2" />
                <div className="text-lg sm:text-2xl text-gray-900">4.9</div>
                <div className="text-xs sm:text-sm text-gray-600">средний рейтинг</div>
              </Card>
              <Card className="p-3 sm:p-4 text-center bg-white border-orange-200">
                <Trophy className="w-6 h-6 sm:w-8 sm:h-8 text-orange-600 mx-auto mb-2" />
                <div className="text-lg sm:text-2xl text-gray-900">95%</div>
                <div className="text-xs sm:text-sm text-gray-600">довольных клиентов</div>
              </Card>
            </div>

            <Card className="p-6 bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200">
              <h4 className="text-lg text-gray-900 mb-3">Специализация</h4>
              <div className="space-y-2">
                <Badge variant="secondary" className="mr-2 mb-2 bg-blue-100 text-blue-700">
                  Личная психология
                </Badge>
                <Badge variant="secondary" className="mr-2 mb-2 bg-green-100 text-green-700">
                  Семейная психология
                </Badge>
                <Badge variant="secondary" className="mr-2 mb-2 bg-purple-100 text-purple-700">
                  Бизнес-коучинг
                </Badge>
                <Badge variant="secondary" className="mr-2 mb-2 bg-orange-100 text-orange-700">
                  Работа с тревогой
                </Badge>
                <Badge variant="secondary" className="mr-2 mb-2 bg-pink-100 text-pink-700">
                  Личностный рост
                </Badge>
              </div>
            </Card>
          </div>
        </div>

        {/* Методы работы */}
        <div className="bg-white rounded-2xl p-8 shadow-lg">
          <h3 className="text-2xl text-gray-900 mb-6 text-center">Методы работы</h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-blue-600" />
              </div>
              <h4 className="text-lg text-gray-900 mb-2">Гуманистический подход</h4>
              <p className="text-gray-600 text-sm">
                Принятие и поддержка, фокус на ресурсах и потенциале клиента
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Lightbulb className="w-8 h-8 text-green-600" />
              </div>
              <h4 className="text-lg text-gray-900 mb-2">Когнитивно-поведенческая терапия</h4>
              <p className="text-gray-600 text-sm">
                Работа с мыслями и поведением для достижения конкретных целей
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-purple-600" />
              </div>
              <h4 className="text-lg text-gray-900 mb-2">Системная семейная терапия</h4>
              <p className="text-gray-600 text-sm">
                Работа с семейными системами и взаимоотношениями
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
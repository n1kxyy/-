import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { User, Users, Briefcase, ArrowRight, Clock, Star } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function ServicesSection() {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const services = [
    {
      icon: User,
      title: "Личный психолог",
      description: "Помощь в познании себя, работа с эмоциями, личностный рост и самореализация",
      image: "https://images.unsplash.com/photo-1629049224884-af8734824449?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXJzb25hbCUyMGdyb3d0aCUyMG1lZGl0YXRpb258ZW58MXx8fHwxNzU3NzU3NjIwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      benefits: [
        "Разберитесь в своих чувствах и эмоциях",
        "Повысите самооценку и уверенность",
        "Найдите свое предназначение",
        "Преодолейте тревогу и стресс"
      ],
      color: "blue",
      price: "от 3 500 ₽"
    },
    {
      icon: Users,
      title: "Семейный психолог", 
      description: "Работа с парами и семьями, решение конфликтов, улучшение взаимопонимания",
      image: "https://images.unsplash.com/photo-1654613698246-b6d44aef0fd5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW1pbHklMjB0aGVyYXB5JTIwY291bnNlbGluZ3xlbnwxfHx8fDE3NTc3NDY5MjR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      benefits: [
        "Наладьте отношения в семье",
        "Решите семейные конфликты",
        "Улучшите коммуникацию",
        "Создайте гармонию в отношениях"
      ],
      color: "green",
      price: "от 4 500 ₽"
    },
    {
      icon: Briefcase,
      title: "Бизнес-психология",
      description: "Поддержка предпринимателей, развитие лидерских качеств, управление стрессом",
      image: "https://images.unsplash.com/photo-1745970347703-687874c5ddbc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMGNvYWNoaW5nJTIwbGVhZGVyc2hpcHxlbnwxfHx8fDE3NTc3NTc2MjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      benefits: [
        "Развейте лидерские навыки",
        "Управляйте рабочим стрессом",
        "Повысьте мотивацию команды",
        "Достигните бизнес-целей"
      ],
      color: "purple",
      price: "от 5 000 ₽"
    }
  ];

  return (
    <section id="services" className="py-16 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="bg-blue-100 text-blue-700 border-blue-200 mb-4">
            <Briefcase className="w-4 h-4 mr-1" />
            Услуги
          </Badge>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl mb-4 text-gray-900 px-4 sm:px-0 break-words">
            Направления работы
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto px-4 sm:px-0 break-words">
            Предлагаю комплексный подход к решению различных жизненных задач. 
            Выберите направление, которое подходит именно вам.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            const colorClasses = {
              blue: {
                badge: "bg-blue-100 text-blue-700 border-blue-200",
                icon: "bg-blue-100 text-blue-600",
                button: "bg-blue-600 hover:bg-blue-700"
              },
              green: {
                badge: "bg-green-100 text-green-700 border-green-200", 
                icon: "bg-green-100 text-green-600",
                button: "bg-green-600 hover:bg-green-700"
              },
              purple: {
                badge: "bg-purple-100 text-purple-700 border-purple-200",
                icon: "bg-purple-100 text-purple-600", 
                button: "bg-purple-600 hover:bg-purple-700"
              }
            };

            return (
              <Card key={index} className="overflow-hidden hover:shadow-xl transition-shadow duration-300">
                <div className="aspect-video relative">
                  <ImageWithFallback
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 left-4">
                    <Badge className={colorClasses[service.color as keyof typeof colorClasses].badge}>
                      <IconComponent className="w-4 h-4 mr-1" />
                      {service.title}
                    </Badge>
                  </div>
                </div>

                <div className="p-4 sm:p-6">
                  <div className="flex items-center mb-4">
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center mr-4 ${colorClasses[service.color as keyof typeof colorClasses].icon}`}>
                      <IconComponent className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-xl text-gray-900 mb-1">{service.title}</h3>
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 text-gray-400 mr-1" />
                        <span className="text-sm text-gray-600">60 минут</span>
                      </div>
                    </div>
                  </div>

                  <p className="text-gray-600 mb-6 break-words">{service.description}</p>

                  <div className="space-y-3 mb-6">
                    {service.benefits.map((benefit, benefitIndex) => (
                      <div key={benefitIndex} className="flex items-center">
                        <Star className="w-4 h-4 text-yellow-500 mr-2 flex-shrink-0" />
                        <span className="text-sm text-gray-700 break-words">{benefit}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-2xl text-gray-900">{service.price}</div>
                      <div className="text-sm text-gray-600">за сессию</div>
                    </div>
                    <Button 
                      onClick={scrollToContact}
                      className={`text-white px-4 sm:px-6 py-2 rounded-lg text-sm sm:text-base leading-tight ${colorClasses[service.color as keyof typeof colorClasses].button}`}
                    >
                      Записаться
                      <ArrowRight className="w-4 h-4 ml-1 sm:ml-2 flex-shrink-0" />
                    </Button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Дополнительная информация */}
        <div className="mt-16 bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-8">
          <div className="text-center mb-8">
            <h3 className="text-2xl text-gray-900 mb-4">Форматы работы</h3>
            <p className="text-gray-600">Выберите удобный для вас способ проведения консультаций</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <Card className="p-6 text-center bg-white">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <h4 className="text-lg text-gray-900 mb-2">Онлайн консультации</h4>
              <p className="text-gray-600 text-sm">
                Видеосвязь через Zoom, Skype или WhatsApp из любой точки мира
              </p>
            </Card>

            <Card className="p-6 text-center bg-white">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Clock className="w-6 h-6 text-green-600" />
              </div>
              <h4 className="text-lg text-gray-900 mb-2">Гибкое расписание</h4>
              <p className="text-gray-600 text-sm">
                Подберем удобное время, включая вечерние часы и выходные
              </p>
            </Card>

            <Card className="p-6 text-center bg-white">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Star className="w-6 h-6 text-purple-600" />
              </div>
              <h4 className="text-lg text-gray-900 mb-2">Первая консультация</h4>
              <p className="text-gray-600 text-sm">
                30-минутная предварительная встреча для знакомства - бесплатно
              </p>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  MessageCircle, 
  Phone, 
  Clock, 
  MapPin, 
  Shield,
  CheckCircle,
  Star,
  Calendar
} from 'lucide-react';

export function ContactSection() {
  const handleWhatsAppClick = () => {
    const message = encodeURIComponent('Здравствуйте, пишу по консультации психолога');
    window.open(`https://wa.me/79232205524?text=${message}`, '_blank');
  };

  const handleTelegramClick = () => {
    window.open('https://t.me/+79232205524', '_blank');
  };

  const handlePhoneClick = () => {
    window.open('tel:+79232205524', '_blank');
  };

  return (
    <section id="contact" className="py-16 bg-gradient-to-br from-blue-50 via-white to-purple-50 overflow-hidden">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="text-center mb-8 sm:mb-12 w-full">
          <Badge variant="secondary" className="bg-green-100 text-green-700 border-green-200 mb-4">
            <MessageCircle className="w-4 h-4 mr-1" />
            Связаться со мной
          </Badge>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl mb-4 text-gray-900 px-2 sm:px-0">
            Запишитесь на консультацию
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto px-2 sm:px-0">
            Готов помочь вам в решении жизненных задач. Выберите удобный способ связи 
            и запишитесь на первую консультацию уже сегодня.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6 sm:gap-8 lg:gap-12 mb-8 sm:mb-12 w-full">
          {/* Способы связи */}
          <div className="w-full min-w-0">
            <h3 className="text-xl sm:text-2xl text-gray-900 mb-4 sm:mb-6 px-2 sm:px-0">Способы связи</h3>
            <div className="space-y-3 sm:space-y-4">
              {/* WhatsApp */}
              <Card className="p-3 sm:p-4 lg:p-6 hover:shadow-lg transition-shadow duration-300 cursor-pointer bg-green-50 border-green-200" onClick={handleWhatsAppClick}>
                <div className="flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0">
                  <div className="flex items-center flex-1">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-green-100 rounded-lg flex items-center justify-center mr-3 sm:mr-4 flex-shrink-0">
                      <MessageCircle className="w-5 h-5 sm:w-6 sm:h-6 text-green-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-base sm:text-lg text-gray-900 mb-1">WhatsApp</h4>
                      <p className="text-sm sm:text-base text-gray-600 mb-2 sm:mb-2">Быстрый способ связи и записи на консультацию</p>
                      <Badge variant="secondary" className="bg-green-100 text-green-700 border-green-200 text-xs sm:text-sm">
                        Рекомендуется
                      </Badge>
                    </div>
                  </div>
                  <Button className="bg-green-600 hover:bg-green-700 text-white w-full sm:w-auto px-4 sm:px-6 py-2 text-sm sm:text-base flex-shrink-0">
                    Написать
                  </Button>
                </div>
              </Card>

              {/* Telegram */}
              <Card className="p-3 sm:p-4 lg:p-6 hover:shadow-lg transition-shadow duration-300 cursor-pointer bg-blue-50 border-blue-200" onClick={handleTelegramClick}>
                <div className="flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0">
                  <div className="flex items-center flex-1">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-3 sm:mr-4 flex-shrink-0">
                      <MessageCircle className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-base sm:text-lg text-gray-900 mb-1">Telegram</h4>
                      <p className="text-sm sm:text-base text-gray-600">Альтернативный мессенджер для связи</p>
                    </div>
                  </div>
                  <Button className="bg-blue-600 hover:bg-blue-700 text-white w-full sm:w-auto px-4 sm:px-6 py-2 text-sm sm:text-base flex-shrink-0">
                    Написать
                  </Button>
                </div>
              </Card>

              {/* Телефон */}
              <Card className="p-3 sm:p-4 lg:p-6 hover:shadow-lg transition-shadow duration-300 cursor-pointer" onClick={handlePhoneClick}>
                <div className="flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0">
                  <div className="flex items-center flex-1">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gray-100 rounded-lg flex items-center justify-center mr-3 sm:mr-4 flex-shrink-0">
                      <Phone className="w-5 h-5 sm:w-6 sm:h-6 text-gray-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-base sm:text-lg text-gray-900 mb-1">Телефон</h4>
                      <p className="text-sm sm:text-base text-gray-600 break-words">8 (923) 220-55-24</p>
                    </div>
                  </div>
                  <Button variant="outline" className="border-gray-300 text-gray-700 hover:bg-gray-50 w-full sm:w-auto px-4 sm:px-6 py-2 text-sm sm:text-base flex-shrink-0">
                    Позвонить
                  </Button>
                </div>
              </Card>


            </div>
          </div>

          {/* Информация о консультациях */}
          <div className="w-full min-w-0">
            <h3 className="text-xl sm:text-2xl text-gray-900 mb-4 sm:mb-6 px-2 sm:px-0">Информация о консультациях</h3>
            
            <Card className="p-4 sm:p-6 bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200 mb-4 sm:mb-6 w-full">
              <div className="flex items-center mb-4">
                <Star className="w-6 h-6 text-yellow-500 mr-2" />
                <h4 className="text-lg text-gray-900">Первая консультация - бесплатно!</h4>
              </div>
              <p className="text-gray-600 mb-4">
                30-минутная встреча для знакомства и определения направления работы. 
                Никаких обязательств — просто познакомимся и поймем, подходим ли мы друг другу.
              </p>
              <Button 
                onClick={handleWhatsAppClick}
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white w-full text-xs xs:text-sm sm:text-base py-3 sm:py-4 px-2 sm:px-4 min-h-[48px] sm:min-h-[52px] leading-tight"
              >
                <Calendar className="w-4 h-4 mr-1 sm:mr-2 flex-shrink-0" />
                <span className="text-center">
                  <span className="block xs:inline">Записаться на бесплатную</span>
                  <span className="block xs:inline xs:ml-1">консультацию</span>
                </span>
              </Button>
            </Card>

            <div className="space-y-3 sm:space-y-4 w-full">
              <div className="flex items-start">
                <Clock className="w-4 h-4 sm:w-5 sm:h-5 text-blue-600 mr-2 sm:mr-3 mt-0.5 flex-shrink-0" />
                <div className="min-w-0 flex-1">
                  <span className="text-sm sm:text-base text-gray-900 block sm:inline">Время работы:</span>
                  <span className="text-sm sm:text-base text-gray-600 block sm:inline sm:ml-2">Пн-Пт: 9:00-21:00, Сб-Вс: 10:00-18:00</span>
                </div>
              </div>
              
              <div className="flex items-start">
                <MapPin className="w-4 h-4 sm:w-5 sm:h-5 text-green-600 mr-2 sm:mr-3 mt-0.5 flex-shrink-0" />
                <div className="min-w-0 flex-1">
                  <span className="text-sm sm:text-base text-gray-900 block sm:inline">Формат:</span>
                  <span className="text-sm sm:text-base text-gray-600 block sm:inline sm:ml-2">Онлайн консультации по всему миру</span>
                </div>
              </div>
              
              <div className="flex items-start">
                <Shield className="w-4 h-4 sm:w-5 sm:h-5 text-purple-600 mr-2 sm:mr-3 mt-0.5 flex-shrink-0" />
                <div className="min-w-0 flex-1">
                  <span className="text-sm sm:text-base text-gray-900 block sm:inline">Конфиденциальность:</span>
                  <span className="text-sm sm:text-base text-gray-600 block sm:inline sm:ml-2">100% защита персональных данных</span>
                </div>
              </div>
            </div>

            <Card className="p-4 sm:p-6 mt-4 sm:mt-6 bg-white border-gray-200 w-full">
              <h4 className="text-base sm:text-lg text-gray-900 mb-3 sm:mb-4">Что включает консультация:</h4>
              <div className="space-y-2 sm:space-y-3">
                <div className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-600 mr-3" />
                  <span className="text-gray-700 text-sm">Диагностика текущего состояния</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-600 mr-3" />
                  <span className="text-gray-700 text-sm">Постановка целей и задач</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-600 mr-3" />
                  <span className="text-gray-700 text-sm">Составление плана работы</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-600 mr-3" />
                  <span className="text-gray-700 text-sm">Домашние задания и техники</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-600 mr-3" />
                  <span className="text-gray-700 text-sm">Поддержка между сессиями</span>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* Призыв к действию */}
        <Card className="bg-gradient-to-r from-green-600 to-blue-600 text-white p-4 sm:p-6 lg:p-8 text-center w-full overflow-hidden">
          <h3 className="text-xl sm:text-2xl mb-3 sm:mb-4 px-2">Готовы сделать первый шаг?</h3>
          <p className="text-green-100 mb-4 sm:mb-6 text-base sm:text-lg max-w-2xl mx-auto px-2">
            Изменения начинаются с одного решения. Не откладывайте свое счастье на завтра — 
            начните путь к лучшей версии себя уже сегодня.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center w-full max-w-lg mx-auto">
            <Button 
              onClick={handleWhatsAppClick}
              className="bg-white text-green-600 hover:bg-gray-100 px-4 sm:px-6 lg:px-8 py-2 sm:py-3 text-sm sm:text-base lg:text-lg w-full"
            >
              <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
              Написать в WhatsApp
            </Button>
            <Button 
              onClick={handleTelegramClick}
              className="bg-white/20 text-white hover:bg-white/30 border border-white/30 px-4 sm:px-6 lg:px-8 py-2 sm:py-3 text-sm sm:text-base lg:text-lg w-full"
            >
              <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
              Написать в Telegram
            </Button>
          </div>
        </Card>

        {/* Дополнительные гарантии */}
        <div className="mt-8 sm:mt-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 w-full">
          <Card className="p-4 sm:p-6 text-center bg-white">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Shield className="w-6 h-6 text-green-600" />
            </div>
            <h4 className="text-base sm:text-lg text-gray-900 mb-2">Безопасность</h4>
            <p className="text-gray-600 text-xs sm:text-sm leading-relaxed">
              Все данные защищены и не передаются третьим лицам. Полная конфиденциальность.
            </p>
          </Card>

          <Card className="p-4 sm:p-6 text-center bg-white">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Clock className="w-6 h-6 text-blue-600" />
            </div>
            <h4 className="text-base sm:text-lg text-gray-900 mb-2">Гибкий график</h4>
            <p className="text-gray-600 text-xs sm:text-sm leading-relaxed">
              Подберем удобное время для консультаций, включая вечерние часы и выходные.
            </p>
          </Card>

          <Card className="p-4 sm:p-6 text-center bg-white sm:col-span-2 lg:col-span-1">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Star className="w-6 h-6 text-purple-600" />
            </div>
            <h4 className="text-base sm:text-lg text-gray-900 mb-2">Качество</h4>
            <p className="text-gray-600 text-xs sm:text-sm leading-relaxed">
              Научно-обоснованные методы и индивидуальный подход к каждому клиенту.
            </p>
          </Card>
        </div>
      </div>
    </section>
  );
}
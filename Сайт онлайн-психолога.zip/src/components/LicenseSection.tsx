import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Shield, Award, GraduationCap, CheckCircle } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function LicenseSection() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="bg-green-100 text-green-700 border-green-200 mb-4">
            <Shield className="w-4 h-4 mr-1" />
            Официальная лицензия
          </Badge>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl mb-4 text-gray-900 px-4 sm:px-0 break-words">
            Доверие и профессионализм
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto px-4 sm:px-0 break-words">
            Работаю на основании официальной лицензии. Все консультации проводятся 
            в соответствии с этическими стандартами психологической практики.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Информация о лицензии */}
          <div>
            <Card className="p-4 sm:p-6 lg:p-8 bg-gradient-to-br from-green-50 to-blue-50 border-green-200">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                  <Award className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="text-xl text-gray-900 mb-1">Лицензия № ПС-2024-001</h3>
                  <p className="text-gray-600">Министерство здравоохранения РФ</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 break-words">Высшее психологическое образование</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 break-words">Профессиональная переподготовка</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 break-words">Регулярное повышение квалификации</span>
                </div>
                <div className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700 break-words">Член Российского психологического общества</span>
                </div>
              </div>

              <div className="mt-6 p-4 bg-white rounded-lg border border-green-200">
                <div className="flex items-center mb-2">
                  <GraduationCap className="w-5 h-5 text-blue-600 mr-2" />
                  <span className="text-gray-900">Образование</span>
                </div>
                <p className="text-gray-700 text-sm">
                  МГУ им. М.В. Ломоносова, факультет психологии<br />
                  Специализация: клиническая и семейная психология
                </p>
              </div>
            </Card>
          </div>

          {/* Изображение сертификата */}
          <div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-green-400 to-blue-500 rounded-2xl transform -rotate-2"></div>
              <Card className="relative p-4 bg-white transform rotate-1 shadow-xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1638636241638-aef5120c5153?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwc3ljaG9sb2d5JTIwZGlwbG9tYSUyMGNlcnRpZmljYXRlfGVufDF8fHx8MTc1Nzc1NzYyMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Диплом психолога"
                  className="w-full h-[300px] object-cover rounded-lg"
                />
                <div className="mt-4 text-center">
                  <Badge variant="outline" className="border-green-200 text-green-700">
                    Официальный документ
                  </Badge>
                </div>
              </Card>
            </div>
          </div>
        </div>

        {/* Дополнительные гарантии */}
        <div className="mt-12 sm:mt-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          <Card className="p-4 sm:p-6 text-center bg-blue-50 border-blue-200">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Shield className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-lg text-gray-900 mb-2">Конфиденциальность</h3>
            <p className="text-gray-600 text-sm">
              Строгое соблюдение врачебной тайны и защита персональных данных
            </p>
          </Card>

          <Card className="p-4 sm:p-6 text-center bg-green-50 border-green-200">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Award className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="text-lg text-gray-900 mb-2">Качество</h3>
            <p className="text-gray-600 text-sm">
              Научно-обоснованные методы и индивидуальный подход к каждому клиенту
            </p>
          </Card>

          <Card className="p-4 sm:p-6 text-center bg-purple-50 border-purple-200 sm:col-span-2 lg:col-span-1">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-lg text-gray-900 mb-2">Результат</h3>
            <p className="text-gray-600 text-sm">
              Комплексная поддержка и сопровождение до достижения целей
            </p>
          </Card>
        </div>
      </div>
    </section>
  );
}
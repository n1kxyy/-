import React from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Star, Award, Users, Clock } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function HeroSection() {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="hero" className="pt-20 pb-16 bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Левая колонка - текст */}
          <div className="order-2 lg:order-1">
            <div className="flex items-center space-x-2 mb-4">
              <Badge variant="secondary" className="bg-blue-100 text-blue-700 border-blue-200">
                <Award className="w-4 h-4 mr-1" />
                Лицензированный психолог
              </Badge>
            </div>
            
            <h1 className="text-3xl sm:text-4xl lg:text-5xl mb-6 text-gray-900 leading-tight px-2 sm:px-0 break-words">
              Профессиональная помощь <span className="text-blue-600">психолога</span> онлайн
            </h1>
            
            <p className="text-lg sm:text-xl text-gray-600 mb-8 leading-relaxed px-2 sm:px-0 break-words">
              Более 10 лет опыта в личной и семейной психологии. Помогу разобраться в себе, 
              наладить отношения и найти внутреннюю гармонию.
            </p>

            {/* Статистика */}
            <div className="grid grid-cols-3 gap-2 sm:gap-4 mb-8 px-2 sm:px-0">
              <div className="text-center p-3 sm:p-4 bg-white rounded-xl shadow-sm">
                <Users className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600 mx-auto mb-2" />
                <div className="text-xl sm:text-2xl text-gray-900">500+</div>
                <div className="text-xs sm:text-sm text-gray-600">Клиентов</div>
              </div>
              <div className="text-center p-3 sm:p-4 bg-white rounded-xl shadow-sm">
                <Clock className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600 mx-auto mb-2" />
                <div className="text-xl sm:text-2xl text-gray-900">10+</div>
                <div className="text-xs sm:text-sm text-gray-600">Лет опыта</div>
              </div>
              <div className="text-center p-3 sm:p-4 bg-white rounded-xl shadow-sm">
                <Star className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600 mx-auto mb-2" />
                <div className="text-xl sm:text-2xl text-gray-900">4.9</div>
                <div className="text-xs sm:text-sm text-gray-600">Рейтинг</div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 px-2 sm:px-0">
              <Button 
                onClick={scrollToContact}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 sm:px-6 lg:px-8 py-3 rounded-lg text-sm sm:text-base lg:text-lg w-full sm:w-auto min-h-[48px] leading-tight"
              >
                <span className="text-center">
                  <span className="block xs:inline">Записаться на</span>
                  <span className="block xs:inline xs:ml-1">консультацию</span>
                </span>
              </Button>
              <Button 
                variant="outline"
                onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
                className="border-blue-200 text-blue-700 hover:bg-blue-50 px-6 sm:px-8 py-3 rounded-lg text-base sm:text-lg w-full sm:w-auto"
              >
                Узнать больше
              </Button>
            </div>
          </div>

          {/* Правая колонка - изображение */}
          <div className="order-1 lg:order-2">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-400 to-purple-500 rounded-2xl transform rotate-3"></div>
              <div className="relative bg-white p-2 rounded-2xl shadow-xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1714976694810-85add1a29c96?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBmZW1hbGUlMjBwc3ljaG9sb2dpc3QlMjB0aGVyYXBpc3R8ZW58MXx8fHwxNzU3NzU3NjE5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Психолог Пётр"
                  className="w-full h-[400px] object-cover rounded-xl"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
const fs = require('fs');
const path = require('path');

console.log('🔄 Начинаем копирование компонентов...\n');

// Список компонентов для копирования
const components = [
  'AboutSection.tsx',
  'ContactSection.tsx', 
  'DirectionsSection.tsx',
  'Footer.tsx',
  'HeroSection.tsx',
  'LicenseSection.tsx',
  'ReviewsSection.tsx',
  'ServicesSection.tsx'
];

// Создаем папку src/components если не существует
const srcComponentsDir = './src/components';
if (!fs.existsSync(srcComponentsDir)) {
  fs.mkdirSync(srcComponentsDir, { recursive: true });
  console.log('📁 Создана папка src/components');
}

// Копируем основные компоненты
console.log('📋 Копируем основные компоненты:');
components.forEach(component => {
  const sourcePath = path.join('./components', component);
  const targetPath = path.join(srcComponentsDir, component);
  
  if (fs.existsSync(sourcePath)) {
    fs.copyFileSync(sourcePath, targetPath);
    console.log(`  ✅ ${component}`);
  } else {
    console.log(`  ❌ Не найден: ${component}`);
  }
});

// Копируем папку figma
console.log('\n🖼️  Копируем Figma компоненты:');
const figmaSourceDir = './components/figma';
const figmaTargetDir = './src/components/figma';

if (fs.existsSync(figmaSourceDir)) {
  if (!fs.existsSync(figmaTargetDir)) {
    fs.mkdirSync(figmaTargetDir, { recursive: true });
  }
  
  const figmaFiles = fs.readdirSync(figmaSourceDir);
  figmaFiles.forEach(file => {
    const sourcePath = path.join(figmaSourceDir, file);
    const targetPath = path.join(figmaTargetDir, file);
    fs.copyFileSync(sourcePath, targetPath);
    console.log(`  ✅ figma/${file}`);
  });
} else {
  console.log('  ⚠️  Папка figma не найдена');
}

// Копируем папку ui
console.log('\n🎨 Копируем UI компоненты:');
const uiSourceDir = './components/ui';
const uiTargetDir = './src/components/ui';

if (fs.existsSync(uiSourceDir)) {
  if (!fs.existsSync(uiTargetDir)) {
    fs.mkdirSync(uiTargetDir, { recursive: true });
  }
  
  const uiFiles = fs.readdirSync(uiSourceDir);
  let uiCount = 0;
  uiFiles.forEach(file => {
    const sourcePath = path.join(uiSourceDir, file);
    const targetPath = path.join(uiTargetDir, file);
    fs.copyFileSync(sourcePath, targetPath);
    uiCount++;
  });
  console.log(`  ✅ Скопировано ${uiCount} UI компонентов`);
} else {
  console.log('  ❌ Папка ui не найдена');
}

console.log('\n🎉 Все компоненты успешно скопированы!');
console.log('📂 Структура готова для сборки\n');
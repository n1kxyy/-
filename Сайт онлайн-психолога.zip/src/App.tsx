import React from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { LicenseSection } from './components/LicenseSection';
import { AboutSection } from './components/AboutSection';
import { ServicesSection } from './components/ServicesSection';
import { DirectionsSection } from './components/DirectionsSection';
import { ReviewsSection } from './components/ReviewsSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <HeroSection />
        <LicenseSection />
        <AboutSection />
        <ServicesSection />
        <DirectionsSection />
        <ReviewsSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}
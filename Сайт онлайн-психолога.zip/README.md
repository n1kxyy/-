
  # Сайт онлайн-психолога

  This is a code bundle for Сайт онлайн-психолога. The original project is available at https://www.figma.com/design/Ds3up0YjWHqhdeqJvh1Xje/%D0%A1%D0%B0%D0%B9%D1%82-%D0%BE%D0%BD%D0%BB%D0%B0%D0%B9%D0%BD-%D0%BF%D1%81%D0%B8%D1%85%D0%BE%D0%BB%D0%BE%D0%B3%D0%B0.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  